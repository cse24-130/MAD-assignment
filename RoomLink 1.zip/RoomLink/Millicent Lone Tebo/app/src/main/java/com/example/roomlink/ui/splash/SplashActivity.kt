package com.example.roomlink.ui.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.roomlink.R
import com.example.roomlink.data.DatabaseInitializer
import com.example.roomlink.ui.auth.LoginActivity
import com.example.roomlink.ui.dashboard.DashboardActivity
import com.example.roomlink.utils.PreferenceManager

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // 1. Initialise and seed the database with 50 students and 50 listings in the background
        DatabaseInitializer.seedDatabase(this) {
            // 2. Perform session check after database is successfully ready
            Handler(Looper.getMainLooper()).postDelayed({
                val prefs = PreferenceManager(this)
                val intent = if (prefs.isLoggedIn()) {
                    Intent(this, DashboardActivity::class.java)
                } else {
                    Intent(this, LoginActivity::class.java)
                }
                startActivity(intent)
                finish()
            }, 2000)
        }
    }
}
