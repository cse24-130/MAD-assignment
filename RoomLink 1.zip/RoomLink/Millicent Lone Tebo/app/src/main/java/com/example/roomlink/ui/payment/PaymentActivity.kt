package com.example.roomlink.ui.payment

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.roomlink.R
import com.example.roomlink.repository.StayRepository
import com.example.roomlink.utils.PreferenceManager

class PaymentActivity : AppCompatActivity() {

    private lateinit var repository: StayRepository
    private lateinit var prefs: PreferenceManager

    private var listingId: Int = -1
    private var stayTitle: String = ""
    private var rentAmount: Double = 0.0
    private var depositAmount: Double = 0.0
    private var totalAmount: Double = 0.0

    private lateinit var tvStayTitle: TextView
    private lateinit var tvRentVal: TextView
    private lateinit var tvDepositVal: TextView
    private lateinit var tvTotalVal: TextView

    private lateinit var etCardName: EditText
    private lateinit var etCardNumber: EditText
    private lateinit var etCardExpiry: EditText
    private lateinit var etCardCVV: EditText
    private lateinit var btnSubmit: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        repository = StayRepository(this)
        prefs = PreferenceManager(this)

        // Read intent extras
        listingId = intent.getIntExtra("LISTING_ID", -1)
        stayTitle = intent.getStringExtra("LISTING_TITLE") ?: "Stay Accommodation"
        rentAmount = intent.getDoubleExtra("LISTING_PRICE", 0.0)
        depositAmount = intent.getDoubleExtra("LISTING_DEPOSIT", 0.0)
        totalAmount = rentAmount + depositAmount

        if (listingId == -1) {
            Toast.makeText(this, "Invalid accommodation ID.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Find views
        val btnBack = findViewById<ImageView>(R.id.btnPaymentBack)
        tvStayTitle = findViewById(R.id.tvPaymentStayTitle)
        tvRentVal = findViewById(R.id.tvPaymentRentVal)
        tvDepositVal = findViewById(R.id.tvPaymentDepositVal)
        tvTotalVal = findViewById(R.id.tvPaymentTotalVal)

        etCardName = findViewById(R.id.etPaymentCardName)
        etCardNumber = findViewById(R.id.etPaymentCardNumber)
        etCardExpiry = findViewById(R.id.etPaymentCardExpiry)
        etCardCVV = findViewById(R.id.etPaymentCardCVV)
        btnSubmit = findViewById(R.id.btnPaymentSubmit)

        // Prepopulate student name
        etCardName.setText(prefs.getUserName())

        // Bind data
        tvStayTitle.text = stayTitle
        tvRentVal.text = "BWP ${String.format("%,.2f", rentAmount)}"
        tvDepositVal.text = "BWP ${String.format("%,.2f", depositAmount)}"
        tvTotalVal.text = "BWP ${String.format("%,.2f", totalAmount)}"

        btnBack.setOnClickListener { finish() }

        btnSubmit.setOnClickListener {
            validateAndProcessPayment()
        }
    }

    private fun validateAndProcessPayment() {
        val cardHolder = etCardName.text.toString().trim()
        val cardNo = etCardNumber.text.toString().trim()
        val expiry = etCardExpiry.text.toString().trim()
        val cvv = etCardCVV.text.toString().trim()

        if (cardHolder.isEmpty()) {
            Toast.makeText(this, "Please enter cardholder name", Toast.LENGTH_SHORT).show()
            return
        }

        // Strip spaces or dashes for digit validation
        val digitsOnly = cardNo.replace(" ", "").replace("-", "")
        if (digitsOnly.length < 13 || digitsOnly.length > 19 || !digitsOnly.all { it.isDigit() }) {
            Toast.makeText(this, "Please enter a valid card number (13-19 digits)", Toast.LENGTH_SHORT).show()
            return
        }

        if (expiry.isEmpty() || !expiry.contains("/")) {
            Toast.makeText(this, "Please enter expiry date in MM/YY format", Toast.LENGTH_SHORT).show()
            return
        }

        if (cvv.length < 3 || cvv.length > 4 || !cvv.all { it.isDigit() }) {
            Toast.makeText(this, "Please enter a valid 3 or 4 digit CVV", Toast.LENGTH_SHORT).show()
            return
        }

        // Create booking reservation in the repository (prevents double bookings on concurrent transactions)
        val userId = prefs.getUserId()
        if (userId == -1) {
            Toast.makeText(this, "Error: User session expired. Please log in again.", Toast.LENGTH_SHORT).show()
            return
        }

        btnSubmit.isEnabled = false
        btnSubmit.text = "Processing Secure Payment..."

        repository.createReservation(userId, listingId, totalAmount) { reservation, message ->
            if (reservation != null) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                // Redirect to ReceiptActivity
                val intent = Intent(this, ReceiptActivity::class.java).apply {
                    putExtra("RESERVATION_ID", reservation.id)
                    putExtra("LISTING_ID", listingId)
                    putExtra("REFERENCE", reservation.paymentReference)
                    putExtra("AMOUNT", reservation.amountPaid)
                    putExtra("TIMESTAMP", reservation.paymentDate)
                    putExtra("TITLE", stayTitle)
                    putExtra("STUDENT_NAME", cardHolder)
                }
                startActivity(intent)
                finish()
            } else {
                btnSubmit.isEnabled = true
                btnSubmit.text = "Authorize Deposit Payment"
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            }
        }
    }
}
