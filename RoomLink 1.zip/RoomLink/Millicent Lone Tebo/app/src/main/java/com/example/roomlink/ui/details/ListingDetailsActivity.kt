package com.example.roomlink.ui.details

import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.roomlink.R
import com.example.roomlink.data.Listing
import com.example.roomlink.repository.StayRepository
import com.example.roomlink.ui.chat.ChatActivity
import com.example.roomlink.ui.payment.PaymentActivity

class ListingDetailsActivity : AppCompatActivity() {

    private lateinit var repository: StayRepository
    private var listingId: Int = -1
    private var currentListing: Listing? = null

    private lateinit var ivDetailImage: ImageView
    private lateinit var tvStatusBadge: TextView
    private lateinit var tvPrice: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvLocation: TextView
    private lateinit var tvTypeVal: TextView
    private lateinit var tvDateVal: TextView
    private lateinit var tvDepositVal: TextView
    private lateinit var tvDescVal: TextView
    private lateinit var llAmenitiesList: LinearLayout
    private lateinit var btnBook: Button
    private lateinit var btnMessage: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        repository = StayRepository(this)
        listingId = intent.getIntExtra("LISTING_ID", -1)

        if (listingId == -1) {
            Toast.makeText(this, "Error: Listing not found.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Find views
        val btnBack = findViewById<ImageView>(R.id.btnDetailBack)
        val btnShare = findViewById<ImageView>(R.id.btnDetailShare)
        ivDetailImage = findViewById(R.id.ivDetailImage)
        tvStatusBadge = findViewById(R.id.tvDetailStatusBadge)
        tvPrice = findViewById(R.id.tvDetailPrice)
        tvTitle = findViewById(R.id.tvDetailTitle)
        tvLocation = findViewById(R.id.tvDetailLocation)
        tvTypeVal = findViewById(R.id.tvDetailTypeVal)
        tvDateVal = findViewById(R.id.tvDetailDateVal)
        tvDepositVal = findViewById(R.id.tvDetailDepositVal)
        tvDescVal = findViewById(R.id.tvDetailDescVal)
        llAmenitiesList = findViewById(R.id.llDetailAmenitiesList)
        btnBook = findViewById(R.id.btnDetailBook)
        btnMessage = findViewById(R.id.btnDetailMessage)

        // Setup simple triggers
        btnBack.setOnClickListener { finish() }
        btnShare.setOnClickListener { shareStayDetails() }

        btnMessage.setOnClickListener {
            currentListing?.let { listing ->
                val intent = Intent(this, ChatActivity::class.java).apply {
                    putExtra("LISTING_ID", listing.id)
                    putExtra("LISTING_TITLE", listing.title)
                }
                startActivity(intent)
            }
        }

        btnBook.setOnClickListener {
            currentListing?.let { listing ->
                if (listing.reservationStatus == "Reserved") {
                    Toast.makeText(this, "This accommodation is already reserved!", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val intent = Intent(this, PaymentActivity::class.java).apply {
                    putExtra("LISTING_ID", listing.id)
                    putExtra("LISTING_TITLE", listing.title)
                    putExtra("LISTING_PRICE", listing.price)
                    putExtra("LISTING_DEPOSIT", listing.depositAmount)
                }
                startActivity(intent)
            }
        }

        loadListingDetails()
    }

    override fun onResume() {
        super.onResume()
        loadListingDetails()
    }

    private fun loadListingDetails() {
        repository.getListingById(listingId) { listing ->
            if (listing != null) {
                currentListing = listing
                bindListing(listing)
            } else {
                Toast.makeText(this, "Accommodation detail failed to load.", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun bindListing(listing: Listing) {
        tvPrice.text = "BWP ${listing.price.toInt()} / month"
        tvTitle.text = listing.title
        tvLocation.text = "${listing.location}, Gaborone"
        tvTypeVal.text = listing.type
        tvDateVal.text = listing.availabilityDate
        tvDepositVal.text = "BWP ${listing.depositAmount.toInt()}"

        // Dynamically resolve and set listing image
        val resId = resources.getIdentifier(listing.imageResId, "drawable", packageName)
        if (resId != 0) {
            ivDetailImage.setImageResource(resId)
        } else {
            ivDetailImage.setImageResource(R.drawable.ic_house)
        }

        // Customise description if available
        tvDescVal.text = "This premium ${listing.type.lowercase()} is located in the safe neighborhood of ${listing.location}, Gaborone. Features modern furnishings, robust safety gates, and direct access to public transport links. Highly recommended for tertiary students seeking a quiet, studious environment with all modern utilities."

        // Bind status badge
        if (listing.reservationStatus == "Available") {
            tvStatusBadge.text = "Available"
            tvStatusBadge.setBackgroundResource(R.drawable.bg_button)
            tvStatusBadge.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.status_available_green))
            
            btnBook.isEnabled = true
            btnBook.text = "Book Stay"
            btnBook.backgroundTintList = null
        } else {
            tvStatusBadge.text = "Reserved"
            tvStatusBadge.setBackgroundResource(R.drawable.bg_button)
            tvStatusBadge.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.status_reserved_red))
            
            btnBook.isEnabled = false
            btnBook.text = "Reserved"
            btnBook.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.text_gray))
        }

        // Dynamically build amenities list
        llAmenitiesList.removeAllViews()
        val list = listing.amenities.split(",")
        for (amenity in list) {
            if (amenity.trim().isNotEmpty()) {
                val tvAmenity = TextView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins(0, 4, 0, 4)
                    }
                    text = "•   ${amenity.trim()}"
                    setTextColor(ContextCompat.getColor(context, R.color.text_dark))
                    textSize = 14f
                }
                llAmenitiesList.addView(tvAmenity)
            }
        }
    }

    private fun shareStayDetails() {
        currentListing?.let { listing ->
            val shareText = """
                Check out this student accommodation in Gaborone!
                🏡 ${listing.title}
                📍 Location: ${listing.location}
                💰 Price: BWP ${listing.price.toInt()}/month
                ✨ Amenities: ${listing.amenities}
                📲 Find out more on RoomLink!
            """.trimIndent()

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Student Accommodation Option")
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            startActivity(Intent.createChooser(intent, "Share via"))
        }
    }
}
