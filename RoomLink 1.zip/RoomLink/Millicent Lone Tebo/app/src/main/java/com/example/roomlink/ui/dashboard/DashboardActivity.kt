package com.example.roomlink.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.roomlink.R
import com.example.roomlink.repository.StayRepository
import com.example.roomlink.ui.chat.ChatActivity
import com.example.roomlink.ui.filter.FilterActivity
import com.example.roomlink.ui.listings.ListingsActivity
import com.example.roomlink.ui.profile.ProfileActivity
import com.example.roomlink.utils.PreferenceManager

class DashboardActivity : AppCompatActivity() {

    private lateinit var prefs: PreferenceManager
    private lateinit var repository: StayRepository
    private lateinit var tvWelcomeGreeting: TextView
    private lateinit var tvBookingsCount: TextView
    private lateinit var tvSavedCount: TextView
    private lateinit var tvMessagesCount: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        prefs = PreferenceManager(this)
        repository = StayRepository(this)

        // 1. Initialise personalized greeting
        tvWelcomeGreeting = findViewById(R.id.tvWelcomeGreeting)
        tvWelcomeGreeting.text = "Welcome 👋"

        tvBookingsCount = findViewById(R.id.tvBookingsCount)
        tvSavedCount = findViewById(R.id.tvSavedCount)
        tvMessagesCount = findViewById(R.id.tvMessagesCount)

        // 2. Setup button clicks
        val btnSearchLauncher = findViewById<LinearLayout>(R.id.btnSearchLauncher)
        btnSearchLauncher.setOnClickListener {
            val intent = Intent(this, ListingsActivity::class.java)
            startActivity(intent)
        }

        val btnViewListings = findViewById<LinearLayout>(R.id.btnViewListings)
        btnViewListings.setOnClickListener {
            val intent = Intent(this, ListingsActivity::class.java)
            startActivity(intent)
        }

        // Quick search filters
        findViewById<LinearLayout>(R.id.btnQuickLocation).setOnClickListener {
            val intent = Intent(this, FilterActivity::class.java)
            startActivity(intent)
        }
        findViewById<LinearLayout>(R.id.btnQuickPrice).setOnClickListener {
            val intent = Intent(this, FilterActivity::class.java)
            startActivity(intent)
        }
        findViewById<LinearLayout>(R.id.btnQuickDate).setOnClickListener {
            val intent = Intent(this, FilterActivity::class.java)
            startActivity(intent)
        }

        // Categories
        findViewById<LinearLayout>(R.id.btnTypeRooms).setOnClickListener { launchCategory("Rooms") }
        findViewById<LinearLayout>(R.id.btnTypeFlats).setOnClickListener { launchCategory("Flats") }
        findViewById<LinearLayout>(R.id.btnTypeApartments).setOnClickListener { launchCategory("Apartments") }
        findViewById<LinearLayout>(R.id.btnTypeTownhouses).setOnClickListener { launchCategory("Townhouses") }

        // Alert Prefs card
        val btnSetPreferences = findViewById<LinearLayout>(R.id.btnSetPreferences)
        btnSetPreferences.setOnClickListener {
            val intent = Intent(this, FilterActivity::class.java)
            startActivity(intent)
        }

        // Quick metrics dashboard buttons
        findViewById<RelativeLayout>(R.id.btnSavedListingsingsingsingsings).setOnClickListener {
            Toast.makeText(this, "Saved stays details", Toast.LENGTH_SHORT).show()
        }
        findViewById<RelativeLayout>(R.id.btnDashboardBookings).setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        findViewById<RelativeLayout>(R.id.btnDashboardMessages).setOnClickListener {
            val intent = Intent(this, ChatActivity::class.java)
            intent.putExtra("LISTING_ID", 1)
            intent.putExtra("LISTING_TITLE", "Featured CBD Flat")
            startActivity(intent)
        }

        // Top layout triggers
        findViewById<View>(R.id.btnMenu).setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        findViewById<View>(R.id.btnNotificationAlert).setOnClickListener {
            Toast.makeText(this, "Stay Updated: All listings are synced!", Toast.LENGTH_SHORT).show()
        }

        // Bottom Nav navigation bindings
        findViewById<LinearLayout>(R.id.btnNavHome).setOnClickListener {
            // Already home
        }
        findViewById<LinearLayout>(R.id.btnNavSearch).setOnClickListener {
            val intent = Intent(this, ListingsActivity::class.java)
            startActivity(intent)
        }
        findViewById<LinearLayout>(R.id.btnNavMessages).setOnClickListener {
            val intent = Intent(this, ChatActivity::class.java)
            intent.putExtra("LISTING_ID", 1)
            intent.putExtra("LISTING_TITLE", "Featured CBD Flat")
            startActivity(intent)
        }
        findViewById<LinearLayout>(R.id.btnNavProfile).setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

        loadDynamicData()
    }

    override fun onResume() {
        super.onResume()
        loadDynamicData()
    }

    private fun launchCategory(category: String) {
        val intent = Intent(this, ListingsActivity::class.java).apply {
            putExtra("FILTER_CATEGORY", category)
        }
        startActivity(intent)
    }

    private fun loadDynamicData() {
        // Fetch bookings count dynamically
        val userId = prefs.getUserId()
        repository.getReservationsForUser(userId) { list ->
            tvBookingsCount.text = "${list.size} active"
        }
        
        // Seed default counter metrics
        tvSavedCount.text = "4 listings"
        tvMessagesCount.text = "1 unread"
    }
}
