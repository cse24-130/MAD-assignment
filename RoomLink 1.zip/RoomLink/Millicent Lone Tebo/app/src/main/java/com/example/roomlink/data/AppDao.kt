package com.example.roomlink.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface AppDao {
    // === User Queries ===
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertUser(user: User): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertUsers(users: List<User>)

    @Query("SELECT * FROM users WHERE email = :email AND passwordHash = :password LIMIT 1")
    fun loginUser(email: String, password: String): User?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    fun getUserByEmail(email: String): User?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserById(id: Int): User?

    @Query("SELECT COUNT(*) FROM users")
    fun getAllUsersCount(): Int

    // === Listing Queries ===
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertListings(listings: List<Listing>)

    @Query("SELECT * FROM listings")
    fun getAllListings(): List<Listing>

    @Query("SELECT * FROM listings WHERE id = :id LIMIT 1")
    fun getListingById(id: Int): Listing?

    @Update
    fun updateListing(listing: Listing)

    @Query("SELECT COUNT(*) FROM listings")
    fun getAllListingsCount(): Int

    // === Reservation Queries ===
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertReservation(reservation: Reservation): Long

    @Query("SELECT * FROM reservations WHERE userId = :userId")
    fun getReservationsByUserId(userId: Int): List<Reservation>

    @Query("SELECT * FROM reservations WHERE listingId = :listingId LIMIT 1")
    fun getReservationByListingId(listingId: Int): Reservation?

    // === Chat Queries ===
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertChat(chat: Chat)

    @Query("SELECT * FROM chats WHERE listingId = :listingId ORDER BY timestamp ASC")
    fun getChatsByListing(listingId: Int): List<Chat>

    @Query("SELECT * FROM chats ORDER BY timestamp DESC")
    fun getAllChats(): List<Chat>
}
