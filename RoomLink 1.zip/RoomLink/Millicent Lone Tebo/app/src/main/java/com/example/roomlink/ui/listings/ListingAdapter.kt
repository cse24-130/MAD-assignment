package com.example.roomlink.ui.listings

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.roomlink.R
import com.example.roomlink.data.Listing

class ListingAdapter(
    private var list: List<Listing>,
    private val onClick: (Listing) -> Unit
) : RecyclerView.Adapter<ListingAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvItemTitle)
        val tvPrice: TextView = view.findViewById(R.id.tvItemPrice)
        val tvLocation: TextView = view.findViewById(R.id.tvItemLocation)
        val tvType: TextView = view.findViewById(R.id.tvItemType)
        val tvAvailability: TextView = view.findViewById(R.id.tvItemAvailability)
        val tvStatus: TextView = view.findViewById(R.id.tvItemStatus)
        val tvAmenities: TextView = view.findViewById(R.id.tvItemAmenities)
        val ivItemImage: ImageView = view.findViewById(R.id.ivItemImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_listing, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = list[position]
        holder.tvTitle.text = item.title
        holder.tvPrice.text = "BWP ${item.price.toInt()}"
        holder.tvLocation.text = "${item.location}, Gaborone"
        holder.tvType.text = item.type
        holder.tvAvailability.text = item.availabilityDate
        holder.tvAmenities.text = item.amenities.replace(",", " • ")

        // Load dynamic listing image
        val context = holder.itemView.context
        val resId = context.resources.getIdentifier(item.imageResId, "drawable", context.packageName)
        if (resId != 0) {
            holder.ivItemImage.setImageResource(resId)
        } else {
            holder.ivItemImage.setImageResource(R.drawable.ic_house)
        }

        // Bind status color pill
        if (item.reservationStatus == "Available") {
            holder.tvStatus.text = "Available"
            holder.tvStatus.setBackgroundResource(R.drawable.bg_button)
            holder.tvStatus.backgroundTintList = ContextCompat.getColorStateList(holder.itemView.context, R.color.status_available_green)
        } else {
            holder.tvStatus.text = "Reserved"
            holder.tvStatus.setBackgroundResource(R.drawable.bg_button)
            holder.tvStatus.backgroundTintList = ContextCompat.getColorStateList(holder.itemView.context, R.color.status_reserved_red)
        }

        holder.itemView.setOnClickListener {
            onClick(item)
        }
    }

    override fun getItemCount(): Int = list.size

    fun updateData(newList: List<Listing>) {
        list = newList
        notifyDataSetChanged()
    }
}
