package com.example.roomlink.ui.chat

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.roomlink.R
import com.example.roomlink.data.Chat
import com.example.roomlink.repository.StayRepository
import com.example.roomlink.utils.PreferenceManager

class ChatActivity : AppCompatActivity() {

    private lateinit var repository: StayRepository
    private lateinit var prefs: PreferenceManager

    private var listingId: Int = -1
    private var listingTitle: String = ""
    private var userId: Int = -1

    private lateinit var chatScrollView: ScrollView
    private lateinit var chatContainer: LinearLayout
    private lateinit var etMessage: EditText
    private lateinit var btnSend: Button
    private lateinit var tvChatSubtitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        repository = StayRepository(this)
        prefs = PreferenceManager(this)

        listingId = intent.getIntExtra("LISTING_ID", 1)
        listingTitle = intent.getStringExtra("LISTING_TITLE") ?: "Modern Single Room - Block 6"
        userId = prefs.getUserId()

        if (userId == -1) {
            Toast.makeText(this, "Session expired. Please sign in.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Find views
        val btnBack = findViewById<ImageView>(R.id.btnChatBack)
        tvChatSubtitle = findViewById(R.id.tvChatSubtitle)
        chatScrollView = findViewById(R.id.chatScrollView)
        chatContainer = findViewById(R.id.chatContainer)
        etMessage = findViewById(R.id.etChatMessage)
        btnSend = findViewById(R.id.btnChatSend)

        // Bind header detail
        tvChatSubtitle.text = "Regarding: $listingTitle"

        btnBack.setOnClickListener { finish() }

        btnSend.setOnClickListener {
            sendMessage()
        }

        loadChatHistory()
    }

    private fun loadChatHistory() {
        repository.getChatHistory(listingId) { chats ->
            chatContainer.removeAllViews()
            if (chats.isEmpty()) {
                // If conversation history is empty, insert a welcome landlord message dynamically
                insertInitialLandlordMessage()
            } else {
                for (chat in chats) {
                    addBubbleToLayout(chat)
                }
                scrollChatToBottom()
            }
        }
    }

    private fun insertInitialLandlordMessage() {
        val initialChat = Chat(
            senderId = -1, // Landlord ID
            receiverId = userId,
            listingId = listingId,
            message = "Hello! Thanks for your interest in '$listingTitle'. I'm the landlord agent for this property in Gaborone. How can I assist you with your stay today? Let me know if you would like to arrange a viewing or discuss prices.",
            timestamp = System.currentTimeMillis() - 60000,
            senderName = "Landlord Agent"
        )
        repository.sendChatMessage(initialChat) {
            loadChatHistory()
        }
    }

    private fun sendMessage() {
        val msgText = etMessage.text.toString().trim()
        if (msgText.isEmpty()) return

        etMessage.setText("")

        val userChat = Chat(
            senderId = userId,
            receiverId = -1,
            listingId = listingId,
            message = msgText,
            timestamp = System.currentTimeMillis(),
            senderName = prefs.getUserName()
        )

        // 1. Send User message to local database
        repository.sendChatMessage(userChat) { success ->
            if (success) {
                loadChatHistory()

                // 2. Trigger automated landlord reply to simulate real-time persistent chats
                Handler(Looper.getMainLooper()).postDelayed({
                    simulateLandlordReply(msgText)
                }, 1500)
            }
        }
    }

    private fun simulateLandlordReply(studentMessage: String) {
        val lowerMsg = studentMessage.lowercase()
        val replyText = when {
            lowerMsg.contains("price") || lowerMsg.contains("rent") || lowerMsg.contains("cost") || lowerMsg.contains("deposit") -> {
                "Our rates for '$listingTitle' are highly competitive for Gaborone. The security deposit is fully refundable at checkout. Let me know if you'd like to check out now!"
            }
            lowerMsg.contains("visit") || lowerMsg.contains("view") || lowerMsg.contains("see") -> {
                "We would love to show you the property! Viewings can be scheduled during weekdays between 9 AM and 4 PM. Would tomorrow at 2 PM work for you?"
            }
            lowerMsg.contains("amenities") || lowerMsg.contains("wifi") || lowerMsg.contains("water") || lowerMsg.contains("power") -> {
                "Yes, high-speed WiFi, secure access fencing, backup power systems, and municipal water connections are fully pre-configured and included in the listing amenities."
            }
            lowerMsg.contains("safe") || lowerMsg.contains("security") || lowerMsg.contains("crime") -> {
                "Security is our top priority! The property has electric gates, 24/7 security guard presence, and burglar bars on all windows."
            }
            else -> {
                "Thank you for the message! I've noted your preference. Let me know if you would like to proceed with the booking checkout, or if there is anything else you need."
            }
        }

        val landlordChat = Chat(
            senderId = -1,
            receiverId = userId,
            listingId = listingId,
            message = replyText,
            timestamp = System.currentTimeMillis(),
            senderName = "Landlord Agent"
        )

        repository.sendChatMessage(landlordChat) { success ->
            if (success) {
                loadChatHistory()
            }
        }
    }

    private fun addBubbleToLayout(chat: Chat) {
        val isUser = chat.senderId == userId

        val bubbleLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 8, 0, 8)
            }
        }

        val tvSenderName = TextView(this).apply {
            text = if (isUser) "You" else chat.senderName
            setTextColor(ContextCompat.getColor(context, R.color.text_gray))
            textSize = 10f
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = if (isUser) Gravity.END else Gravity.START
                setMargins(6, 0, 6, 2)
            }
        }
        bubbleLayout.addView(tvSenderName)

        val tvMessage = TextView(this).apply {
            text = chat.message
            textSize = 14f
            setPadding(16, 12, 16, 12)
            maxWidth = (resources.displayMetrics.widthPixels * 0.75).toInt()

            if (isUser) {
                setBackgroundResource(R.drawable.bg_chat_outgoing)
                setTextColor(ContextCompat.getColor(context, R.color.white))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    gravity = Gravity.END
                }
            } else {
                setBackgroundResource(R.drawable.bg_chat_incoming)
                setTextColor(ContextCompat.getColor(context, R.color.text_dark))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    gravity = Gravity.START
                }
            }
        }
        bubbleLayout.addView(tvMessage)

        chatContainer.addView(bubbleLayout)
    }

    private fun scrollChatToBottom() {
        chatScrollView.post {
            chatScrollView.fullScroll(ScrollView.FOCUS_DOWN)
        }
    }
}
