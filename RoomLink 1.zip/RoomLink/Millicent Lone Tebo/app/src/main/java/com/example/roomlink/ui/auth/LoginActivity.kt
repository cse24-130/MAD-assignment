package com.example.roomlink.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.roomlink.R
import com.example.roomlink.repository.StayRepository
import com.example.roomlink.ui.dashboard.DashboardActivity
import com.example.roomlink.utils.PreferenceManager

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnSignIn = findViewById<Button>(R.id.btnSignIn)
        val tvRegisterRedirect = findViewById<TextView>(R.id.tvRegisterRedirect)

        val repository = StayRepository(this)
        val prefs = PreferenceManager(this)

        btnSignIn.setOnClickListener {
            val emailInput = etEmail.text.toString().trim()
            val email = if (emailInput.contains("@")) emailInput else "$emailInput@university.bw"
            val password = etPassword.text.toString()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all credentials", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Authenticate user
            repository.login(email, password) { user ->
                if (user != null) {
                    // Save login session
                    prefs.saveSession(user.id, user.name, user.email, user.phone)
                    Toast.makeText(this, "Welcome, ${user.name}!", Toast.LENGTH_SHORT).show()
                    
                    // Redirect to Dashboard
                    val intent = Intent(this, DashboardActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this, "Invalid credentials. Try: student1 / password1", Toast.LENGTH_LONG).show()
                }
            }
        }

        tvRegisterRedirect.setOnClickListener {
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
        }
    }
}
