package com.example.roomlink.ui.profile

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.roomlink.R
import com.example.roomlink.repository.StayRepository
import com.example.roomlink.ui.auth.LoginActivity
import com.example.roomlink.utils.PreferenceManager

class ProfileActivity : AppCompatActivity() {

    private lateinit var prefs: PreferenceManager
    private lateinit var repository: StayRepository

    private lateinit var tvName: TextView
    private lateinit var tvStudentID: TextView
    private lateinit var tvEmail: TextView
    private lateinit var tvPhone: TextView
    private lateinit var tvReservationsCount: TextView
    private lateinit var btnSignOut: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        prefs = PreferenceManager(this)
        repository = StayRepository(this)

        val userId = prefs.getUserId()
        if (userId == -1) {
            Toast.makeText(this, "Session expired.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Find views
        val btnBack = findViewById<ImageView>(R.id.btnProfileBack)
        tvName = findViewById(R.id.tvProfileName)
        tvStudentID = findViewById(R.id.tvProfileStudentID)
        tvEmail = findViewById(R.id.tvProfileEmail)
        tvPhone = findViewById(R.id.tvProfilePhone)
        tvReservationsCount = findViewById(R.id.tvProfileReservationsCount)
        btnSignOut = findViewById(R.id.btnProfileSignOut)

        // Bind basic session info as initial/temporary values
        tvName.text = prefs.getUserName()
        tvEmail.text = prefs.getUserEmail()
        tvPhone.text = prefs.getUserPhone()

        // Fetch actual user details from the database using the user's ID
        repository.getUserById(userId) { user ->
            if (user != null) {
                tvName.text = user.name
                tvEmail.text = user.email
                tvPhone.text = user.phone
                tvStudentID.text = user.studentId
                val roleStr = "${if (user.studentId.isNotEmpty()) "Student ID " + user.studentId else "Verified Student"} • Active"
                findViewById<TextView>(R.id.tvProfileRole).text = roleStr
            }
        }

        btnBack.setOnClickListener { finish() }

        // Sign Out Session action
        btnSignOut.setOnClickListener {
            prefs.clearSession()
            Toast.makeText(this, "Logged out successfully.", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
            finish()
        }

        loadReservationsCount(userId)
    }

    private fun loadReservationsCount(userId: Int) {
        repository.getReservationsForUser(userId) { list ->
            val count = list.size
            tvReservationsCount.text = "$count ${if (count == 1) "booking" else "bookings"} active"
        }
    }
}
