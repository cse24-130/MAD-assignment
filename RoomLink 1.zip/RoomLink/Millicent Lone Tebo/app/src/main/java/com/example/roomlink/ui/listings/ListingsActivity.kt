package com.example.roomlink.ui.listings

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.roomlink.R
import com.example.roomlink.data.Listing
import com.example.roomlink.repository.StayRepository
import com.example.roomlink.ui.details.ListingDetailsActivity
import com.example.roomlink.ui.filter.FilterActivity

class ListingsActivity : AppCompatActivity() {

    private lateinit var repository: StayRepository
    private lateinit var adapter: ListingAdapter
    private lateinit var tvListingsCount: TextView
    private lateinit var etListingsSearch: EditText

    private var allListings: List<Listing> = emptyList()
    private var selectedArea: String = "" // Empty means "All"
    private var categoryFilter: String = "" // Empty means none

    private lateinit var btnAreaAll: Button
    private lateinit var btnAreaBroadhurst: Button
    private lateinit var btnAreaBlock6: Button
    private lateinit var btnAreaBlock8: Button
    private lateinit var btnAreaTlokweng: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listings)

        repository = StayRepository(this)

        // Read intent filters
        categoryFilter = intent.getStringExtra("FILTER_CATEGORY") ?: ""

        // Find views
        val btnBack = findViewById<ImageView>(R.id.btnListingsBack)
        val btnFilter = findViewById<ImageView>(R.id.btnListingsFilter)
        tvListingsCount = findViewById(R.id.tvListingsCount)
        etListingsSearch = findViewById(R.id.etListingsSearch)
        val rvListings = findViewById<RecyclerView>(R.id.rvListingsProperties)

        btnAreaAll = findViewById(R.id.btnAreaAll)
        btnAreaBroadhurst = findViewById(R.id.btnAreaBroadhurst)
        btnAreaBlock6 = findViewById(R.id.btnAreaBlock6)
        btnAreaBlock8 = findViewById(R.id.btnAreaBlock8)
        btnAreaTlokweng = findViewById(R.id.btnAreaTlokweng)

        // Setup recyclerview
        rvListings.layoutManager = LinearLayoutManager(this)
        adapter = ListingAdapter(emptyList()) { listing ->
            val intent = Intent(this, ListingDetailsActivity::class.java).apply {
                putExtra("LISTING_ID", listing.id)
            }
            startActivity(intent)
        }
        rvListings.adapter = adapter

        // Click listeners
        btnBack.setOnClickListener { finish() }
        btnFilter.setOnClickListener {
            val intent = Intent(this, FilterActivity::class.java)
            startActivity(intent)
        }

        // Setup area quick action buttons
        btnAreaAll.setOnClickListener { selectArea("") }
        btnAreaBroadhurst.setOnClickListener { selectArea("Broadhurst") }
        btnAreaBlock6.setOnClickListener { selectArea("Block 6") }
        btnAreaBlock8.setOnClickListener { selectArea("Block 8") }
        btnAreaTlokweng.setOnClickListener { selectArea("Tlokweng") }

        // Setup search filter
        etListingsSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                applyFilters()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        loadListings()
    }

    override fun onResume() {
        super.onResume()
        loadListings()
    }

    private fun loadListings() {
        repository.getAllListings { list ->
            allListings = list
            applyFilters()
        }
    }

    private fun selectArea(area: String) {
        selectedArea = area
        // Update quick action buttons background
        updateAreaButtonStyles()
        applyFilters()
    }

    private fun updateAreaButtonStyles() {
        val activeBg = R.drawable.bg_button
        val activeTextColor = resources.getColor(R.color.white, theme)
        val inactiveBg = R.drawable.bg_button_outline
        val inactiveTextColor = resources.getColor(R.color.colorPrimary, theme)

        // Set all to inactive initially
        btnAreaAll.setBackgroundResource(inactiveBg)
        btnAreaAll.setTextColor(inactiveTextColor)
        btnAreaBroadhurst.setBackgroundResource(inactiveBg)
        btnAreaBroadhurst.setTextColor(inactiveTextColor)
        btnAreaBlock6.setBackgroundResource(inactiveBg)
        btnAreaBlock6.setTextColor(inactiveTextColor)
        btnAreaBlock8.setBackgroundResource(inactiveBg)
        btnAreaBlock8.setTextColor(inactiveTextColor)
        btnAreaTlokweng.setBackgroundResource(inactiveBg)
        btnAreaTlokweng.setTextColor(inactiveTextColor)

        // Set the active one
        when (selectedArea) {
            "" -> {
                btnAreaAll.setBackgroundResource(activeBg)
                btnAreaAll.setTextColor(activeTextColor)
            }
            "Broadhurst" -> {
                btnAreaBroadhurst.setBackgroundResource(activeBg)
                btnAreaBroadhurst.setTextColor(activeTextColor)
            }
            "Block 6" -> {
                btnAreaBlock6.setBackgroundResource(activeBg)
                btnAreaBlock6.setTextColor(activeTextColor)
            }
            "Block 8" -> {
                btnAreaBlock8.setBackgroundResource(activeBg)
                btnAreaBlock8.setTextColor(activeTextColor)
            }
            "Tlokweng" -> {
                btnAreaTlokweng.setBackgroundResource(activeBg)
                btnAreaTlokweng.setTextColor(activeTextColor)
            }
        }
    }

    private fun applyFilters() {
        val query = etListingsSearch.text.toString().trim().lowercase()

        val filtered = allListings.filter { listing ->
            val matchQuery = query.isEmpty() ||
                    listing.title.lowercase().contains(query) ||
                    listing.location.lowercase().contains(query) ||
                    listing.amenities.lowercase().contains(query) ||
                    listing.type.lowercase().contains(query)

            val matchArea = selectedArea.isEmpty() ||
                    listing.location.equals(selectedArea, ignoreCase = true)

            val matchCategory = categoryFilter.isEmpty() ||
                    listing.type.contains(categoryFilter, ignoreCase = true)

            matchQuery && matchArea && matchCategory
        }

        adapter.updateData(filtered)
        tvListingsCount.text = "${filtered.size} stays matched in Gaborone"
    }
}
