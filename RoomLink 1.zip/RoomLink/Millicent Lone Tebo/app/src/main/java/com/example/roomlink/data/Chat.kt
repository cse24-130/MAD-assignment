package com.example.roomlink.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chats")
data class Chat(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val senderId: Int,
    val receiverId: Int,
    val listingId: Int,
    val message: String,
    val timestamp: Long,
    val senderName: String
)
