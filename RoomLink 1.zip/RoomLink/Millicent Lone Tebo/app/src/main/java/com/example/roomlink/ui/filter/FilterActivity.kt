package com.example.roomlink.ui.filter

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.NotificationCompat
import com.example.roomlink.R
import com.example.roomlink.repository.StayRepository
import com.example.roomlink.ui.listings.ListingsActivity
import com.example.roomlink.utils.PreferenceManager

class FilterActivity : AppCompatActivity() {

    private lateinit var prefs: PreferenceManager
    private lateinit var repository: StayRepository

    private lateinit var spLocation: Spinner
    private lateinit var spType: Spinner
    private lateinit var tvBudgetVal: TextView
    private lateinit var sbBudget: SeekBar
    private lateinit var etDate: EditText
    private lateinit var swEnableAlerts: SwitchCompat
    private lateinit var btnApply: Button

    private val areas = arrayOf(
        "All Areas", "Broadhurst", "Block 6", "Block 8", "CBD", "Tlokweng", "Mogoditshane", "Village", "G-West"
    )
    private val types = arrayOf(
        "All Types", "Rooms", "Flats", "Apartments", "Townhouses"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter)

        prefs = PreferenceManager(this)
        repository = StayRepository(this)

        // Find views
        val btnBack = findViewById<ImageView>(R.id.btnFilterBack)
        spLocation = findViewById(R.id.spFilterLocation)
        spType = findViewById(R.id.spFilterType)
        tvBudgetVal = findViewById(R.id.tvFilterBudgetVal)
        sbBudget = findViewById(R.id.sbFilterBudget)
        etDate = findViewById(R.id.etFilterDate)
        swEnableAlerts = findViewById(R.id.swFilterEnableAlerts)
        btnApply = findViewById(R.id.btnFilterApply)

        // Setup back button
        btnBack.setOnClickListener { finish() }

        // Setup Spinners
        val areaAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, areas).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spLocation.adapter = areaAdapter

        val typeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, types).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spType.adapter = typeAdapter

        // Load cached alerts preferences or defaults
        loadCachedPreferences()

        // Seekbar change listener (Offset 1200 BWP, Max seek value 4800 -> 1200 to 6000 BWP range)
        sbBudget.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val price = progress + 1200
                tvBudgetVal.text = "BWP ${String.format("%,d", price)}"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Apply and trigger background matchmaking notifications
        btnApply.setOnClickListener {
            savePreferencesAndCheckMatches()
        }
    }

    private fun loadCachedPreferences() {
        val cachedPrice = prefs.getAlertPrice()
        val cachedLoc = prefs.getAlertLocation()
        val cachedDate = prefs.getAlertDate()
        val isEnabled = prefs.isAlertEnabled()

        // Map price (1200 to 6000) to seekbar progress (0 to 4800)
        val progress = (cachedPrice.toInt() - 1200).coerceIn(0, 4800)
        sbBudget.progress = progress
        tvBudgetVal.text = "BWP ${String.format("%,d", progress + 1200)}"

        // Map spinner location
        val locIndex = areas.indexOf(cachedLoc)
        if (locIndex >= 0) {
            spLocation.setSelection(locIndex)
        } else {
            spLocation.setSelection(0)
        }

        if (cachedDate.isNotEmpty()) {
            etDate.setText(cachedDate)
        }

        swEnableAlerts.isChecked = isEnabled
    }

    private fun savePreferencesAndCheckMatches() {
        val selectedArea = spLocation.selectedItem.toString()
        val selectedType = spType.selectedItem.toString()
        val maxPrice = (sbBudget.progress + 1200).toFloat()
        val dateText = etDate.text.toString().trim()
        val isAlertEnabled = swEnableAlerts.isChecked

        // 1. Cache alerts preferences in SharedPreferences
        prefs.saveAlertPreferences(maxPrice, selectedArea, dateText, isAlertEnabled)

        // 2. Perform background matchmaking query
        val queryLocation = if (selectedArea == "All Areas") "" else selectedArea
        repository.findMatches(maxPrice.toDouble(), queryLocation) { matches ->
            // Filter by type if not "All Types"
            val typeFiltered = if (selectedType == "All Types") {
                matches
            } else {
                matches.filter { it.type.contains(selectedType, ignoreCase = true) }
            }

            if (isAlertEnabled && typeFiltered.isNotEmpty()) {
                // 3. Trigger Android Notification
                showMatchmakerNotification(typeFiltered.size, selectedArea, maxPrice)
                Toast.makeText(this, "Preferences Saved! Matches found: ${typeFiltered.size}", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Preferences Saved!", Toast.LENGTH_SHORT).show()
            }

            // Redirect back or open listings directly with the matches
            val intent = Intent(this, ListingsActivity::class.java).apply {
                putExtra("FILTER_CATEGORY", if (selectedType == "All Types") "" else selectedType)
            }
            startActivity(intent)
            finish()
        }
    }

    private fun showMatchmakerNotification(matchCount: Int, location: String, budget: Float) {
        val channelId = "matchmaker_channel"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create Channel for API 26+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Accommodation Matchmaker",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifies when student stay matches are found"
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Tap notification opens ListingsActivity
        val intent = Intent(this, ListingsActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val locDetail = if (location == "All Areas") "Gaborone" else location
        val title = "Housing Match Found! 🏡"
        val text = "We found $matchCount stays in $locDetail under BWP ${budget.toInt()} matching your profile. Tap to discover!"

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(101, notification)
    }
}
