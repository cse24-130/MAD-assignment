package com.example.roomlink.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object DatabaseInitializer {

    fun seedDatabase(context: Context, onComplete: () -> Unit) {
        val dao = AppDatabase.getDatabase(context).appDao()
        CoroutineScope(Dispatchers.IO).launch {
            val userCount = dao.getAllUsersCount()
            val listingCount = dao.getAllListingsCount()

            // 1. Seed 50 Users (Students)
            if (userCount == 0) {
                val usersToSeed = mutableListOf<User>()
                for (i in 1..50) {
                    val studId = "2026" + String.format("%05d", i)
                    usersToSeed.add(
                        User(
                            studentId = studId,
                            name = "student$i",
                            email = "student$i@university.bw",
                            phone = "+267 7${(1000000..9999999).random()}",
                            passwordHash = "password$i",
                            role = "Student"
                        )
                    )
                }
                dao.insertUsers(usersToSeed)
            }

            // 2. Seed 50 Gaborone Housing Listings
            if (listingCount == 0) {
                val neighborhoods = listOf("Broadhurst", "Block 6", "Block 8", "CBD", "Tlokweng", "Mogoditshane", "Village", "G-West")
                val types = listOf("Rooms", "Flats", "Apartments", "Townhouses")
                val allAmenities = listOf("WiFi", "Water", "Electricity", "Parking", "Security", "AC", "Furnished", "Study Area")

                val adjectives = listOf("Modern", "Cozy", "Safe", "Sleek", "Premium", "Charming", "Affordable", "Executive", "Comfortable", "Quiet")
                val nouns = listOf("Student Haven", "Bachelor Nest", "Academic Suite", "Campus View Flat", "Stay-Inn Room", "Shared Dorm", "Executive Pad", "Cresta Retreat", "UB Annex", "Lekgotla Villa")

                val listingsToSeed = mutableListOf<Listing>()
                for (i in 1..50) {
                    val neighborhood = neighborhoods[(i - 1) % neighborhoods.size]
                    val type = types[(i - 1) % types.size]
                    val adj = adjectives[(i - 1) % adjectives.size]
                    val noun = nouns[(i - 1) % nouns.size]
                    
                    val price = when(type) {
                        "Rooms" -> (1200..1800).random().toDouble()
                        "Flats" -> (2000..3200).random().toDouble()
                        "Apartments" -> (3500..4500).random().toDouble()
                        "Townhouses" -> (4800..5500).random().toDouble()
                        else -> 2500.0
                    }
                    
                    val deposit = price // 1 month deposit
                    val availability = when(i % 4) {
                        0 -> "Immediate"
                        1 -> "2026-06-01"
                        2 -> "2026-07-01"
                        else -> "2026-08-01"
                    }

                    // Pick random amenities
                    val numAmenities = (3..6).random()
                    val shuffledAmenities = allAmenities.shuffled().take(numAmenities)
                    val amenitiesStr = shuffledAmenities.joinToString(",")

                    val title = "$adj $type in $neighborhood - $noun"
                    
                    // Cyclically assign reservation status to make it realistic
                    val status = if (i % 8 == 0) "Reserved" else "Available"
                    val reservedBy = if (status == "Reserved") 1 else null // Reserved by student1 (User ID 1)

                    listingsToSeed.add(
                        Listing(
                            title = title,
                            price = price,
                            location = neighborhood,
                            type = type,
                            amenities = amenitiesStr,
                            availabilityDate = availability,
                            depositAmount = deposit,
                            imageResId = "img_house_${((i - 1) % 4) + 1}",
                            reservationStatus = status,
                            reservedById = reservedBy
                        )
                    )
                }
                dao.insertListings(listingsToSeed)
            }

            withContext(Dispatchers.Main) {
                onComplete()
            }
        }
    }
}
