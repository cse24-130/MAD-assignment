package com.example.roomlink.utils

import android.content.Context
import android.content.SharedPreferences

class PreferenceManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("student_stay_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_USER_PHONE = "user_phone"

        // Filter alerts preference keys
        private const val KEY_ALERT_PRICE = "alert_price"
        private const val KEY_ALERT_LOCATION = "alert_location"
        private const val KEY_ALERT_DATE = "alert_date"
        private const val KEY_ALERT_ENABLED = "alert_enabled"
    }

    fun saveSession(userId: Int, name: String, email: String, phone: String) {
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, true)
            putInt(KEY_USER_ID, userId)
            putString(KEY_USER_NAME, name)
            putString(KEY_USER_EMAIL, email)
            putString(KEY_USER_PHONE, phone)
            apply()
        }
    }

    fun clearSession() {
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, false)
            putInt(KEY_USER_ID, -1)
            putString(KEY_USER_NAME, "")
            putString(KEY_USER_EMAIL, "")
            putString(KEY_USER_PHONE, "")
            apply()
        }
    }

    fun isLoggedIn(): Boolean {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }

    fun getUserId(): Int {
        return prefs.getInt(KEY_USER_ID, -1)
    }

    fun getUserName(): String {
        return prefs.getString(KEY_USER_NAME, "") ?: ""
    }

    fun getUserEmail(): String {
        return prefs.getString(KEY_USER_EMAIL, "") ?: ""
    }

    fun getUserPhone(): String {
        return prefs.getString(KEY_USER_PHONE, "") ?: ""
    }

    // Save alert parameters for background notifications
    fun saveAlertPreferences(price: Float, location: String, date: String, enabled: Boolean) {
        prefs.edit().apply {
            putFloat(KEY_ALERT_PRICE, price)
            putString(KEY_ALERT_LOCATION, location)
            putString(KEY_ALERT_DATE, date)
            putBoolean(KEY_ALERT_ENABLED, enabled)
            apply()
        }
    }

    fun getAlertPrice(): Float = prefs.getFloat(KEY_ALERT_PRICE, 10000f)
    fun getAlertLocation(): String = prefs.getString(KEY_ALERT_LOCATION, "") ?: ""
    fun getAlertDate(): String = prefs.getString(KEY_ALERT_DATE, "") ?: ""
    fun isAlertEnabled(): Boolean = prefs.getBoolean(KEY_ALERT_ENABLED, false)
}
