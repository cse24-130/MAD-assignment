package com.example.roomlink.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "listings")
data class Listing(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val price: Double, // Price in BWP Pula
    val location: String, // Neighborhood name e.g., "Broadhurst"
    val type: String, // "Rooms", "Flats", "Apartments", "Townhouses"
    val amenities: String, // Comma separated e.g. "WiFi,Water,Security,AC"
    val availabilityDate: String, // e.g. "2026-06-01" or "Immediate"
    val depositAmount: Double, // BWP Deposit
    val imageResId: String, // Simulated image resource ID string e.g., "img_house_1"
    var reservationStatus: String = "Available", // "Available" or "Reserved"
    var reservedById: Int? = null // Nullable Foreign Key to users.id
)
