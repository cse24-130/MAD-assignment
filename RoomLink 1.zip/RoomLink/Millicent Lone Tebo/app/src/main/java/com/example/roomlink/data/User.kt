package com.example.roomlink.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val studentId: String,
    val name: String,
    val email: String,
    val phone: String,
    val passwordHash: String,
    val role: String = "Student" // Student or Provider
)
