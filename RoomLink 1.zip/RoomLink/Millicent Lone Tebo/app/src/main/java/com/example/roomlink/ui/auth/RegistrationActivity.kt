package com.example.roomlink.ui.auth

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.roomlink.R
import com.example.roomlink.data.User
import com.example.roomlink.repository.StayRepository

class RegistrationActivity : AppCompatActivity() {

    // The 5 available registration slots
    private val availableSlots = listOf("student51", "student52", "student53", "student54", "student55")

    private var selectedSlotIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        val spSlot = findViewById<Spinner>(R.id.spRegSlot)
        val etRegStudentID = findViewById<EditText>(R.id.etRegStudentID)
        val etRegEmail = findViewById<EditText>(R.id.etRegEmail)
        val etRegPhone = findViewById<EditText>(R.id.etRegPhone)
        val etRegPassword = findViewById<EditText>(R.id.etRegPassword)
        val btnRegister = findViewById<Button>(R.id.btnRegister)
        val tvLoginRedirect = findViewById<TextView>(R.id.tvLoginRedirect)

        val repository = StayRepository(this)

        // Setup Spinner with slot names
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, availableSlots)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spSlot.adapter = adapter

        // Auto-fill Student ID and Email when a slot is selected
        spSlot.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedSlotIndex = position
                val slotNumber = 51 + position
                etRegStudentID.setText("2026" + String.format("%05d", slotNumber))
                etRegEmail.setText("student$slotNumber@university.bw")
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Keep defaults
            }
        }

        btnRegister.setOnClickListener {
            val slotNumber = 51 + selectedSlotIndex
            val name = "student$slotNumber"
            val studentId = etRegStudentID.text.toString().trim()
            val email = etRegEmail.text.toString().trim()
            val phone = etRegPhone.text.toString().trim()
            val password = etRegPassword.text.toString()

            if (phone.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in your phone number and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password.length < 4) {
                Toast.makeText(this, "Password must be at least 4 characters", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newUser = User(
                studentId = studentId,
                name = name,
                email = email,
                phone = phone,
                passwordHash = password,
                role = "Student"
            )

            repository.register(newUser) { success, msg ->
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                if (success) {
                    Toast.makeText(this, "You can now sign in as $name", Toast.LENGTH_LONG).show()
                    finish() // Close and go back to login screen
                }
            }
        }

        tvLoginRedirect.setOnClickListener {
            finish() // Switch back to LoginActivity
        }
    }
}
