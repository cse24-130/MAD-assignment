package com.example.roomlink.repository

import android.content.Context
import com.example.roomlink.data.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class StayRepository(context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val dao = db.appDao()

    fun login(email: String, passwordHash: String, onResult: (User?) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            val user = dao.loginUser(email, passwordHash)
            withContext(Dispatchers.Main) {
                onResult(user)
            }
        }
    }

    fun register(user: User, onResult: (Boolean, String) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            val existing = dao.getUserByEmail(user.email)
            if (existing != null) {
                withContext(Dispatchers.Main) {
                    onResult(false, "Email already registered!")
                }
            } else {
                val rowId = dao.insertUser(user)
                withContext(Dispatchers.Main) {
                    if (rowId > 0) {
                        onResult(true, "Successfully registered!")
                    } else {
                        onResult(false, "Registration failed.")
                    }
                }
            }
        }
    }

    fun getAllListings(onResult: (List<Listing>) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            val listings = dao.getAllListings()
            withContext(Dispatchers.Main) {
                onResult(listings)
            }
        }
    }

    fun getListingById(id: Int, onResult: (Listing?) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            val listing = dao.getListingById(id)
            withContext(Dispatchers.Main) {
                onResult(listing)
            }
        }
    }

    fun getUserById(id: Int, onResult: (User?) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            val user = dao.getUserById(id)
            withContext(Dispatchers.Main) {
                onResult(user)
            }
        }
    }

    // Process a deposit payment, check for duplicate bookings, and reserve
    fun createReservation(userId: Int, listingId: Int, depositPaid: Double, onResult: (Reservation?, String) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            // 1. Fetch listing and check reservation status
            val listing = dao.getListingById(listingId)
            if (listing == null) {
                withContext(Dispatchers.Main) {
                    onResult(null, "Listing not found.")
                }
                return@launch
            }

            if (listing.reservationStatus == "Reserved") {
                withContext(Dispatchers.Main) {
                    onResult(null, "This accommodation has already been reserved!")
                }
                return@launch
            }

            // 2. Check for duplicate reservation in DB
            val existingRes = dao.getReservationByListingId(listingId)
            if (existingRes != null) {
                withContext(Dispatchers.Main) {
                    onResult(null, "This accommodation has already been reserved!")
                }
                return@launch
            }

            // 3. Perform reservation
            val referenceNumber = "REF-${System.currentTimeMillis().toString().takeLast(6)}-BWP"
            val currentDate = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

            val reservation = Reservation(
                listingId = listingId,
                userId = userId,
                paymentReference = referenceNumber,
                amountPaid = depositPaid,
                paymentDate = currentDate
            )

            // Insert reservation
            val resId = dao.insertReservation(reservation)
            if (resId > 0) {
                // Update listing status
                listing.reservationStatus = "Reserved"
                listing.reservedById = userId
                dao.updateListing(listing)

                withContext(Dispatchers.Main) {
                    onResult(reservation.copy(id = resId.toInt()), "Reservation Confirmed!")
                }
            } else {
                withContext(Dispatchers.Main) {
                    onResult(null, "Transaction failed. Please try again.")
                }
            }
        }
    }

    fun getReservationsForUser(userId: Int, onResult: (List<Reservation>) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            val list = dao.getReservationsByUserId(userId)
            withContext(Dispatchers.Main) {
                onResult(list)
            }
        }
    }

    fun getChatHistory(listingId: Int, onResult: (List<Chat>) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            val history = dao.getChatsByListing(listingId)
            withContext(Dispatchers.Main) {
                onResult(history)
            }
        }
    }

    fun sendChatMessage(chat: Chat, onResult: (Boolean) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            dao.insertChat(chat)
            withContext(Dispatchers.Main) {
                onResult(true)
            }
        }
    }

    // Background Matchmaker
    fun findMatches(maxPrice: Double, location: String, onResult: (List<Listing>) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            val listings = dao.getAllListings().filter {
                it.reservationStatus == "Available" &&
                it.price <= maxPrice &&
                (location.isEmpty() || it.location.equals(location, ignoreCase = true))
            }
            withContext(Dispatchers.Main) {
                onResult(listings)
            }
        }
    }
}
