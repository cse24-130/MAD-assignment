package com.example.roomlink.ui.payment

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.roomlink.R
import com.example.roomlink.ui.chat.ChatActivity
import com.example.roomlink.ui.dashboard.DashboardActivity

class ReceiptActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receipt)

        // Read intent extras
        val listingId = intent.getIntExtra("LISTING_ID", -1)
        val reference = intent.getStringExtra("REFERENCE") ?: "REF-UNKNOWN-BWP"
        val amount = intent.getDoubleExtra("AMOUNT", 0.0)
        val timestamp = intent.getStringExtra("TIMESTAMP") ?: ""
        val title = intent.getStringExtra("TITLE") ?: "Stay Accommodation"
        val studentName = intent.getStringExtra("STUDENT_NAME") ?: ""

        // Find views
        val tvRef = findViewById<TextView>(R.id.tvReceiptRef)
        val tvAmount = findViewById<TextView>(R.id.tvReceiptAmount)
        val tvDate = findViewById<TextView>(R.id.tvReceiptDate)
        val tvStayTitle = findViewById<TextView>(R.id.tvReceiptStayTitle)
        val tvStudentName = findViewById<TextView>(R.id.tvReceiptStudentName)
        val btnHome = findViewById<Button>(R.id.btnReceiptHome)
        val btnMessage = findViewById<Button>(R.id.btnReceiptMessage)

        // Bind data
        tvRef.text = reference
        tvAmount.text = "BWP ${String.format("%,.2f", amount)}"
        tvDate.text = timestamp
        tvStayTitle.text = title
        tvStudentName.text = studentName

        // Return Home, clearing navigation history stack
        btnHome.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
            finish()
        }

        // Messaging redirect
        btnMessage.setOnClickListener {
            val intent = Intent(this, ChatActivity::class.java).apply {
                putExtra("LISTING_ID", listingId)
                putExtra("LISTING_TITLE", title)
            }
            startActivity(intent)
        }
    }
}
