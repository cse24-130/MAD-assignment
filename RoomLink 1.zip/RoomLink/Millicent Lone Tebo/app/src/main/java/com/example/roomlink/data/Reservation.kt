package com.example.roomlink.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reservations")
data class Reservation(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val listingId: Int,
    val userId: Int,
    val paymentReference: String,
    val amountPaid: Double,
    val paymentDate: String,
    val status: String = "Confirmed"
)
